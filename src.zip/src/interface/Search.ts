export interface GoogleSearch {
    topic: string;
    related: string[];
}